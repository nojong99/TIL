package Test1;

public class MultiCompus {
	
	static void onlineZoom(eight m) {
		m.watch();
	}
}