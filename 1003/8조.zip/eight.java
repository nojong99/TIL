package Test1;

public class eight {
	public void watch() {
	}
}
