package Test1;

public class show {

	public static void main(String[] args) {
	kim k=new kim();
	noh n=new noh();
	yoon y=new yoon();
	MultiCompus.onlineZoom(k);
	MultiCompus.onlineZoom(n);
	MultiCompus.onlineZoom(y);
	}

}
